//
//  APIUrl's.swift
//  MyswaasthERP
//
//  Created by Innotical  Solutions  on 24/08/17.
//  Copyright © 2017 Innotical  Solutions . All rights reserved.
//

import Foundation
import UIKit





func registerUrl()-> String {
    var  url = "https://reqres.in/api/register/"
    url = url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
    print("registerUrl",url)
    return url
}

