//
//  UserDefault.swift
//  MySwaasthNew
//
//  Created by preeti rani on 28/04/17.
//  Copyright © 2017 Innotical. All rights reserved.
//
let defaults = UserDefaults.standard
import Foundation

enum ProfileInfoKeys : String {
    
   
    case expiresIn
    case refreshToken
    case clientSecret = "clientSecret"
    case clientId = "clientId"
    case accessToken
    
    
}

enum UserLocation :String{
    case lat = "latitude"
    case long = "longtitude"
    case location = "location"
}
struct SaveToDefaults {
    
   
    
    func setExpiresIn(value : Int?) {
        defaults.set(value, forKey: ProfileInfoKeys.expiresIn.rawValue)
        
    }
    func getExpiresIn()->Int?{
        
        let value = defaults.value(forKey: ProfileInfoKeys.expiresIn.rawValue) as? Int
        return value
    }
    
    func setRefreshToken(value : String?) {
        defaults.set(value, forKey: ProfileInfoKeys.refreshToken.rawValue)
        
    }
    func getRefreshToken()->String?{
        
        let value = defaults.value(forKey: ProfileInfoKeys.refreshToken.rawValue) as? String
        return value
    }
    
    func setClientSecret(value : String?) {
        defaults.set(value, forKey: ProfileInfoKeys.clientSecret.rawValue)
        
    }
    func getClientSecret()->String?{
        
        let value = defaults.value(forKey: ProfileInfoKeys.clientSecret.rawValue) as? String
        return value
    }
    
    func setClientId(value : String?) {
        defaults.set(value, forKey: ProfileInfoKeys.clientId.rawValue)
        
    }
    func getClientId()->String?{
        
        let value = defaults.value(forKey: ProfileInfoKeys.clientId.rawValue) as? String
        return value
    }
    
    func setAccessToken(value : String?) {
        defaults.set(value, forKey: ProfileInfoKeys.accessToken.rawValue)
        
    }
    func getAccessToken()->String?{
        
        let value = defaults.value(forKey: ProfileInfoKeys.accessToken.rawValue) as? String
        return value
    }
    
    
  
}
//
//func saveLoginDetails(model : TokenModel, user : UserInfoModel) {
//    SaveToDefaults().setClientSecret(value: model.client_secret)
//    SaveToDefaults().setClientId(value: model.client_id)
//    SaveToDefaults().setAccessToken(value: model.access_token)
//    SaveToDefaults().setName(value: user.name)
//    SaveToDefaults().setEmail(value: user.email)
//    defaults.synchronize()
//}



