//
//  ViewController.swift
//  McKinleyTask
//
//  Created by 1THING on 07/11/19.
//  Copyright © 2019 Innotical. All rights reserved.
//

import UIKit
import SVProgressHUD

class ViewController: UIViewController {

    @IBOutlet weak var idField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func loginBtnTap(_ sender: UIButton) {
        self.hitLoginApi()
    }
    func hitLoginApi(){
        SVProgressHUD.show()
        let param : [String : Any] = ["email" : "eve.holt@reqres.in",
                                      "password" : "pistol"]
        api_manager.POSTApi(registerUrl(), param: param, header: nil) { (response, error, statuscode) in
            SVProgressHUD.dismiss()
           
            if let error = error {
                print(error.localizedDescription)
                //self.showErrorViewofType(.ServerError,"",error: error)
            }
            else if let json = response{
                print(json)
                if json["token"].isKeyPresent(){
                    let token = json["token"].stringValue
                    let vc = WebVC.storyboardInstance()
                    SaveToDefaults().setAccessToken(value: token)
                    vc?.urlStr = "https://mckinleyrice.com/?token=\(token)"
                    self.navigationController?.pushViewController(vc!, animated: true)
                }else{
                    
                }
            }
        }
    }
}

